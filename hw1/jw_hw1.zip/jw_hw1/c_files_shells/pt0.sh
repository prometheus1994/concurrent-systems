#!/bin/bash
i=$1
./pt0 ${i}