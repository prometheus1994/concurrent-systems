#!/bin/bash
i=$1
./pt0_tiled ${i}