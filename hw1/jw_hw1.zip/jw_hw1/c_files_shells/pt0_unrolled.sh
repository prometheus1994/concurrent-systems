#!/bin/bash
i=$1
./pt0_unrolled ${i}