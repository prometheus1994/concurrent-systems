#!/bin/bash
i=$1
j=$2
k=$3

./parallel_pthreads $i $j $k