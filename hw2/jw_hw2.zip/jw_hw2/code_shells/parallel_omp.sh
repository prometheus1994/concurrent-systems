#!/bin/bash
i=$1
j=$2
k=$3

./parallel_omp ${i} ${j} ${k}