#!/bin/bash
i=$1
j=$2

./parallel_origin ${i} ${j}